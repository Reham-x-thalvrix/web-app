# DETOX LOUD 1.00 — Android Studio project

## Included
- App name/version: **Detox Loud 1.00**
- User-supplied logo URL loaded in the app header (internet required)
- Discord button opens the official Discord app, or discord.com/login if Discord is not installed
- Dark dashboard, live input console meter, ON/OFF engine switch
- Swipe up/down bottom control drawer with smooth 220 ms animation
- Four presets: Thunder, Gaming, Radio, Clean
- Four tuning sliders: Master Output, Bass Body, Voice Clarity, Thunder Drive
- Ten DSP controls: Noise Gate, Compressor, De-Esser, Bass Body, Voice Clarity, Exciter, Echo, Reverb, Auto Gain, Safety Limiter
- AudioRecord -> DSP -> AudioTrack monitoring with a soft safety limiter

## Important Discord and Android limitations
The Discord button opens the real Discord app/site. This project does not create a fake Discord login page or collect Discord passwords. It does not yet authenticate the user's Discord account inside Detox Loud; a real in-app account connection would require a registered Discord OAuth2 application and a secure token exchange design.

On ordinary Android devices, a third-party app cannot replace Discord's system microphone input with its processed audio. This app processes microphone audio and plays the result to the selected audio output. Turning the engine OFF releases the microphone and stops processing; it does not alter the microphone used by other apps.

Use headphones to reduce acoustic feedback. Keep listening volume comfortable. Android audio routing and latency vary by device.

## Build
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Install Android SDK Platform 35 if prompted and wait for Gradle Sync.
4. Connect an Android phone and press Run, or choose Build -> Build APK(s).
5. The APK is normally created under `app/build/outputs/apk/debug/`.

This is a starter project, not a signed Play Store release. Test it on the target phone before regular use.
