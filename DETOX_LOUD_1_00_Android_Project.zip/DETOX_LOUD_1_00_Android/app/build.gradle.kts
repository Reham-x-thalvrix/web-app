plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.detoxloud.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.detoxloud.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 100
        versionName = "1.00"
    }
}
